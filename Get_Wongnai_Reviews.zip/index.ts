export interface Env {}

interface Review {
  summary: string;
  description: string;
  rating: number;
}

interface ApiResponse {
  reviews: Review[];
  page: {
    pageInformation: {
      totalNumberOfEntities: number;
    };
  };
}

export default {
  async fetch(request: Request): Promise<Response> {
    const urlParams = new URL(request.url).searchParams;
    const restaurantName = urlParams.get('restaurant');

    if (!restaurantName) {
      return new Response('Please specify a restaurant name in the query parameters, e.g., ?restaurant=sushimasa', { status: 400 });
    }

    let allReviews: { description: string; rating: number }[] = [];
    let currentPage = 1;
    let totalPages = 1;  // เริ่มต้นกำหนดหน้าแรก

    let apiLinks: string[] = [];  // เก็บลิงค์ API สำหรับแต่ละหน้า
    let errors: string[] = [];  // เก็บข้อความ error ถ้ามี

    try {
      // ดึงข้อมูลจากทุกหน้า
      while (true) {
        const apiUrl = `https://www.wongnai.com/_api/restaurants/${encodeURIComponent(restaurantName)}/reviews.json?_v=6.126&locale=th&page.number=${currentPage}&page.size=350&sort.type=1`;

        // เพิ่มลิงค์ API ที่จะให้ผู้ใช้ไปกด
        apiLinks.push(apiUrl);
        
        // ใช้ curl เพื่อให้คุณคัดลอกคำสั่งและใช้งานได้
        console.log(`Link: "${apiUrl}"`);

        const response = await fetch(apiUrl, {
          method: 'GET',
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'application/json',
          },
        });

        if (!response.ok) {
          errors.push(`Failed to fetch page ${currentPage}`);
          break; // ออกจากลูปหากเกิดข้อผิดพลาด
        }

        const data: ApiResponse = await response.json();

        if (!data.reviews || data.reviews.length === 0) {
          break; // Exit loop if no reviews are available
        }

        // คำนวณจำนวนหน้าจากข้อมูลที่ได้
        if (currentPage === 1) {
          totalPages = Math.ceil(data.page.pageInformation.totalNumberOfEntities / 6);  // 6 คือจำนวนรีวิวต่อหน้า
        }

        // ดึงข้อมูลที่ต้องการ (description, rating)
        const reviews = data.reviews.map((review: Review) => ({
          description: review.description || '',
          rating: review.rating || 0,
        }));

        allReviews = allReviews.concat(reviews);

        // ไปยังหน้าถัดไป
        currentPage++;

        // ถ้าครบหน้าทั้งหมดให้หยุด
        if (currentPage > totalPages) {
          break;
        }
      }

      // สร้างหน้าแสดงผลลิงค์ API ที่ให้ผู้ใช้กด
      const htmlResponse = `
        <html>
          <body>
            <h1>API Links for Reviews of "${restaurantName}"</h1>
            <p>Click on the following links to fetch reviews via cURL:</p>
            <ul>
              ${apiLinks.map(link => `<li><a href="${link}" target="_blank">${link}</a></li>`).join('')}
            </ul>
            <br />
            <h2>Errors:</h2>
            ${errors.length > 0 ? '<ul>' + errors.map(error => `<li>${error}</li>`).join('') + '</ul>' : '<p>No errors</p>'}
          </body>
        </html>
      `;

      return new Response(htmlResponse, {
        headers: { 'Content-Type': 'text/html' },
      });

    } catch (error) {
      return new Response(`Error: ${(error as Error).message}`, { status: 500 });
    }
  },
};
